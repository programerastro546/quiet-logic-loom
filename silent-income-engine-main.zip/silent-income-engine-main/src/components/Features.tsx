import { Card } from "@/components/ui/card";
import { Zap, Target, Users, BarChart, Lock, RefreshCw } from "lucide-react";
import feature1 from "@/assets/feature-1.jpg";
import feature2 from "@/assets/feature-2.jpg";
import feature3 from "@/assets/feature-3.jpg";

const features = [
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Generate high-quality content in seconds, not hours. Our AI understands context and delivers exactly what you need.",
    image: feature1,
  },
  {
    icon: Target,
    title: "SEO Optimized",
    description: "Content that ranks. Built-in SEO optimization ensures your content performs well in search engines.",
    image: feature2,
  },
  {
    icon: Users,
    title: "Team Collaboration",
    description: "Work together seamlessly. Share, edit, and manage content with your entire team in real-time.",
    image: feature3,
  },
  {
    icon: BarChart,
    title: "Analytics Dashboard",
    description: "Track performance and ROI with detailed analytics. Know what works and optimize accordingly.",
  },
  {
    icon: Lock,
    title: "Enterprise Security",
    description: "Bank-level encryption and security. Your data is safe and private, always.",
  },
  {
    icon: RefreshCw,
    title: "Unlimited Revisions",
    description: "Not satisfied? Regenerate and refine your content until it's perfect. No limits.",
  },
];

const Features = () => {
  return (
    <section className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold">
            Everything You Need to{" "}
            <span className="gradient-text">Scale Content</span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Powerful features designed to help you create, optimize, and scale your content strategy effortlessly.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="group p-6 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border-border/50 bg-card/50 backdrop-blur-sm"
            >
              {feature.image && (
                <div className="mb-6 rounded-lg overflow-hidden">
                  <img
                    src={feature.image}
                    alt={feature.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                </div>
              )}
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                <feature.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
